import React from 'react';

function web () {
  return <h1>web-development</h1>;
}

export default web;
