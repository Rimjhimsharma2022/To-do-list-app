import React from 'react';

function Navbar () {
  return <h1>Navbar</h1>;
}

export default Navbar;
